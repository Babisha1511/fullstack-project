import { useState, useEffect } from "react";

export default function Settings() {
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  const [profile, setProfile] = useState({
    name: "John Doe",
    email: "john@email.com",
    phone: "+91 98765 43210",
  });

  const [showSuccess, setShowSuccess] = useState(false);
  const [showPasswordPopup, setShowPasswordPopup] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  /* ✅ ACTUAL DARK MODE LOGIC */
  useEffect(() => {
    if (darkMode) {
      document.body.classList.add("bg-black", "text-white");
      document.body.classList.remove("bg-white", "text-black");
    } else {
      document.body.classList.add("bg-white", "text-black");
      document.body.classList.remove("bg-black", "text-white");
    }
  }, [darkMode]);

  return (
    <div
      className="min-h-screen p-8"
      style={{
        backgroundImage:
          "linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.8)), url('https://t3.ftcdn.net/jpg/02/96/19/10/360_F_296191090_PGQXIC2Y8CCsrJ7fgCsDd8OuVN8uJtNY.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        backgroundAttachment: "fixed",
      }}
    >
      {/* HEADER */}
      <h1 className="text-3xl font-bold mb-2">Settings</h1>
      <p className="text-gray-400 mb-10">
        Manage your account preferences and security.
      </p>

      <div className="grid lg:grid-cols-2 gap-10">
        {/* PROFILE */}
        <div className="bg-[#121212] border border-white/10 rounded-2xl p-6">
          <h2 className="text-xl font-semibold mb-6">
            Profile Information
          </h2>

          <div className="space-y-4">
            <Input
              label="Full Name"
              value={profile.name}
              onChange={(v) =>
                setProfile({ ...profile, name: v })
              }
            />
            <Input
              label="Email Address"
              value={profile.email}
              onChange={(v) =>
                setProfile({ ...profile, email: v })
              }
            />
            <Input
              label="Phone Number"
              value={profile.phone}
              onChange={(v) =>
                setProfile({ ...profile, phone: v })
              }
            />
          </div>

          <button
            onClick={() => {
              setShowSuccess(true);
              setTimeout(() => setShowSuccess(false), 2000);
            }}
            className="mt-6 bg-white text-black px-6 py-2 rounded-xl font-semibold"
          >
            Save Changes
          </button>
        </div>

        {/* ACCOUNT */}
        <div className="bg-[#121212] border border-white/10 rounded-2xl p-6">
          <h2 className="text-xl font-semibold mb-6">
            Account Preferences
          </h2>

          <Toggle
            label="Enable Notifications"
            enabled={notifications}
            setEnabled={setNotifications}
          />

          <Toggle
            label="Dark Mode"
            enabled={darkMode}
            setEnabled={setDarkMode}
          />

          <div className="mt-6">
            <button
              onClick={() => setShowPasswordPopup(true)}
              className="border border-white/20 px-6 py-2 rounded-xl text-sm"
            >
              Change Password
            </button>
          </div>
        </div>

        {/* MEMBERSHIP */}
        <div className="bg-[#121212] border border-white/10 rounded-2xl p-6">
          <h2 className="text-xl font-semibold mb-6">
            Membership
          </h2>

          <div className="flex justify-between items-center mb-4">
            <div>
              <p className="font-semibold">
                Pro Athlete Plan
              </p>
              <p className="text-sm text-gray-400">
                Valid until Oct 15, 2024
              </p>
            </div>
            <span className="bg-[#39ff14]/20 text-[#39ff14] px-3 py-1 rounded-full text-xs">
              Active
            </span>
          </div>

          <button className="bg-white text-black px-6 py-2 rounded-xl font-semibold">
            Manage Membership
          </button>
        </div>

        {/* DANGER ZONE */}
        <div className="bg-[#0f0f0f] border border-red-500/30 rounded-2xl p-6">
          <h2 className="text-xl font-semibold text-red-400 mb-4">
            Danger Zone
          </h2>

          <p className="text-sm text-gray-400 mb-6">
            These actions are permanent and cannot be undone.
          </p>

          <div className="flex gap-4">
            <button
              onClick={() =>
                alert("Logged out successfully")
              }
              className="border border-red-500 text-red-400 px-6 py-2 rounded-xl"
            >
              Logout
            </button>
            <button
              onClick={() => setShowDeleteConfirm(true)}
              className="bg-red-600 text-white px-6 py-2 rounded-xl"
            >
              Delete Account
            </button>
          </div>
        </div>
      </div>

      {/* SUCCESS MESSAGE */}
      {showSuccess && (
        <div className="fixed bottom-6 right-6 bg-[#39ff14] text-black px-5 py-3 rounded-lg font-medium">
          ✅ Settings Saved Successfully
        </div>
      )}

      {/* CHANGE PASSWORD */}
      {showPasswordPopup && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-[#121212] p-6 rounded-xl w-96">
            <h3 className="text-lg font-semibold mb-4">
              Change Password
            </h3>

            <input
              type="password"
              placeholder="New Password"
              className="w-full mb-4 p-2 rounded bg-black border border-white/10"
            />

            <div className="flex justify-end gap-3">
              <button
                onClick={() =>
                  setShowPasswordPopup(false)
                }
                className="text-gray-400"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowPasswordPopup(false);
                  alert("Password updated successfully");
                }}
                className="bg-white text-black px-4 py-1 rounded-lg"
              >
                Update
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRM */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-[#121212] p-6 rounded-xl w-96 border border-red-500/30">
            <h3 className="text-lg font-semibold text-red-400 mb-4">
              Confirm Delete Account
            </h3>

            <p className="text-sm text-gray-400 mb-6">
              Are you sure you want to delete your account?
            </p>

            <div className="flex justify-end gap-3">
              <button
                onClick={() =>
                  setShowDeleteConfirm(false)
                }
                className="text-gray-400"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  alert("Account deleted");
                }}
                className="bg-red-600 text-white px-4 py-1 rounded-lg"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* INPUT */
function Input({ label, value, onChange }) {
  return (
    <div>
      <label className="block text-sm text-gray-400 mb-1">
        {label}
      </label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-black border border-white/10 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-white/30"
      />
    </div>
  );
}

/* TOGGLE */
function Toggle({ label, enabled, setEnabled }) {
  return (
    <div className="flex justify-between items-center mb-4">
      <span className="text-sm">{label}</span>
      <button
        onClick={() => setEnabled(!enabled)}
        className={`w-12 h-6 rounded-full relative transition ${
          enabled ? "bg-[#39ff14]" : "bg-gray-600"
        }`}
      >
        <span
          className={`absolute top-1 w-4 h-4 bg-white rounded-full transition ${
            enabled ? "right-1" : "left-1"
          }`}
        />
      </button>
    </div>
  );
}

