export default function StorePaymentAdmin() {
  return (
    <div
      className="p-8 min-h-screen text-white"
      style={{
        backgroundImage:
          "linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.85)), url('https://png.pngtree.com/thumb_back/fh260/background/20230721/pngtree-contemporary-3d-render-of-a-gym-with-modern-interior-design-image_3766556.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        backgroundAttachment: "fixed",
      }}
    >
      {/* HEADER */}
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-3xl font-bold tracking-wide">
            Store & Payments
          </h1>
          <p className="text-gray-400 mt-1">
            Track product sales, memberships, and transactions.
          </p>
        </div>

        <button
          className="px-5 py-2 rounded-lg font-semibold transition"
          style={{
            backgroundColor: "#39ff14",
            color: "black",
            boxShadow: "0 0 20px rgba(57,255,20,0.4)",
          }}
        >
          Export Report
        </button>
      </div>

      {/* STATS */}
      <div className="grid md:grid-cols-4 gap-6 mb-10">
        <Stat title="Total Revenue" value="₹28.4L" />
        <Stat title="Store Sales" value="₹6.2L" />
        <Stat title="Membership Payments" value="₹20.1L" />
        <Stat title="Refund Requests" value="12" />
      </div>

      {/* TRANSACTIONS */}
      <div className="bg-black/70 backdrop-blur-lg border border-white/10 rounded-2xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-gray-400">
            <tr>
              <th className="text-left px-6 py-3">Transaction ID</th>
              <th>User</th>
              <th>Type</th>
              <th>Status</th>
              <th>Date</th>
              <th className="text-right px-6">Amount</th>
            </tr>
          </thead>

          <tbody>
            <PaymentRow
              id="#TXN8821"
              user="Arjun Patel"
              type="Membership"
              status="Completed"
              amount="₹12,000"
            />
            <PaymentRow
              id="#TXN8794"
              user="Sneha Iyer"
              type="Store Purchase"
              status="Completed"
              amount="₹1,800"
            />
            <PaymentRow
              id="#TXN8755"
              user="Rahul Mehta"
              type="Membership"
              status="Pending"
              amount="₹2,000"
            />
            <PaymentRow
              id="#TXN8720"
              user="Karthik"
              type="Refund"
              status="Requested"
              amount="₹1,200"
            />
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* COMPONENTS */

function Stat({ title, value }) {
  return (
    <div className="bg-black/60 backdrop-blur-lg border border-white/10 rounded-2xl p-6 hover:border-[#39ff14]/40 transition">
      <p className="text-gray-400 text-sm mb-2">{title}</p>
      <h2 className="text-3xl font-bold text-[#39ff14]">
        {value}
      </h2>
    </div>
  );
}

function PaymentRow({ id, user, type, status, amount }) {
  const statusStyle = {
    Completed:
      "bg-[#39ff14]/20 text-[#39ff14] border border-[#39ff14]/40",
    Pending: "bg-yellow-500/20 text-yellow-400",
    Requested: "bg-red-500/20 text-red-400",
  };

  return (
    <tr className="border-t border-white/10 hover:bg-white/5 transition">
      <td className="px-6 py-4">{id}</td>
      <td className="text-center">{user}</td>
      <td className="text-center">{type}</td>
      <td className="text-center">
        <span
          className={`px-3 py-1 rounded-full text-xs ${statusStyle[status]}`}
        >
          {status}
        </span>
      </td>
      <td className="text-center text-gray-400">Today</td>
      <td className="px-6 text-right font-semibold text-[#39ff14]">
        {amount}
      </td>
    </tr>
  );
}
