import { useState, useEffect } from "react";

const STORAGE_KEY = "gym_clients";

export default function ClientManagement() {
  const [clients, setClients] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved
      ? JSON.parse(saved)
      : [
          {
            name: "Arjun Patel",
            email: "arjun@gmail.com",
            phone: "+91 98765 12345",
            membership: "Pro",
            trainer: "Alex Fit",
            status: "Active",
          },
          {
            name: "Sneha Iyer",
            email: "sneha@gmail.com",
            phone: "+91 98989 65432",
            membership: "Elite",
            trainer: "Neha Sharma",
            status: "Active",
          },
          {
            name: "Rahul Mehta",
            email: "rahul@gmail.com",
            phone: "+91 97654 32109",
            membership: "Basic",
            trainer: "",
            status: "Expired",
          },
          {
            name: "Pooja Nair",
            email: "pooja@gmail.com",
            phone: "+91 91234 56789",
            membership: "Pro",
            trainer: "Vikram Rao",
            status: "Paused",
          },
        ];
  });

  const [showModal, setShowModal] = useState(false);

  /* ===== SYNC WITH LOCAL STORAGE ===== */
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(clients));
  }, [clients]);

  /* ===== FILTER STATES ===== */
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [membershipFilter, setMembershipFilter] = useState("All");
  const [trainerFilter, setTrainerFilter] = useState("All");

  /* ===== ADD CLIENT ===== */
  const addClient = (client) => {
    setClients([...clients, client]);
    setShowModal(false);
  };

  /* ===== REMOVE CLIENT ===== */
  const removeClient = (email) => {
    setClients(clients.filter((c) => c.email !== email));
  };

  /* ===== FILTER LOGIC ===== */
  const filteredClients = clients.filter((c) => {
    const searchMatch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search);

    const statusMatch =
      statusFilter === "All" || c.status === statusFilter;

    const membershipMatch =
      membershipFilter === "All" || c.membership === membershipFilter;

    const trainerMatch =
      trainerFilter === "All" ||
      (trainerFilter === "Assigned" && c.trainer) ||
      (trainerFilter === "Unassigned" && !c.trainer);

    return searchMatch && statusMatch && membershipMatch && trainerMatch;
  });

  /* ===== STATS ===== */
  const total = clients.length;
  const active = clients.filter((c) => c.status === "Active").length;
  const expired = clients.filter((c) => c.status === "Expired").length;
  const paused = clients.filter((c) => c.status === "Paused").length;

  return (
    <div
      className="p-8 min-h-screen text-white"
      style={{
        backgroundImage:
          "linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.85)), url('https://png.pngtree.com/thumb_back/fh260/background/20230721/pngtree-contemporary-3d-render-of-a-gym-with-modern-interior-design-image_3766556.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        backgroundAttachment: "fixed",
      }}
    >
      {/* ===== HEADER ===== */}
      <div className="flex items-center justify-between mb-10">
        <div>
          <h1 className="text-3xl font-bold">Client Management</h1>
          <p className="text-gray-400 mt-1">
            Manage gym members, memberships, and assigned trainers.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-5 py-2 rounded-lg font-semibold"
          style={{
            backgroundColor: "#39ff14",
            color: "black",
            boxShadow: "0 0 20px rgba(57,255,20,0.4)",
          }}
        >
          ➕ Add Client
        </button>
      </div>

      {/* ===== STATS ===== */}
      <div className="grid md:grid-cols-4 gap-6 mb-10">
        <Stat title="Total Clients" value={total} />
        <Stat title="Active Members" value={active} />
        <Stat title="Expired Plans" value={expired} />
        <Stat title="Paused Members" value={paused} />
      </div>

      {/* ===== SEARCH & FILTERS ===== */}
      <div className="flex flex-col md:flex-row gap-4 items-center mb-6">
        <input
          type="text"
          placeholder="Search by name, email, phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 bg-black/70 border border-white/10 rounded-lg px-4 py-2 outline-none"
        />

        <div className="flex gap-3 text-sm">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-black/70 border border-white/10 rounded-lg px-3 py-2"
          >
            <option value="All">Status: All</option>
            <option>Active</option>
            <option>Expired</option>
            <option>Paused</option>
          </select>

          <select
            value={membershipFilter}
            onChange={(e) => setMembershipFilter(e.target.value)}
            className="bg-black/70 border border-white/10 rounded-lg px-3 py-2"
          >
            <option value="All">Membership</option>
            <option>Basic</option>
            <option>Pro</option>
            <option>Elite</option>
          </select>

          <select
            value={trainerFilter}
            onChange={(e) => setTrainerFilter(e.target.value)}
            className="bg-black/70 border border-white/10 rounded-lg px-3 py-2"
          >
            <option value="All">Trainer</option>
            <option value="Assigned">Assigned</option>
            <option value="Unassigned">Unassigned</option>
          </select>
        </div>
      </div>

      {/* ===== CLIENT TABLE ===== */}
      <div className="bg-black/70 border border-white/10 rounded-2xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-gray-400">
            <tr>
              <th className="text-left px-6 py-3">Client</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Membership</th>
              <th>Trainer</th>
              <th>Status</th>
              <th className="text-right px-6">Actions</th>
            </tr>
          </thead>

          <tbody>
            {filteredClients.map((c, i) => (
              <ClientRow
                key={i}
                {...c}
                onDelete={() => removeClient(c.email)}
              />
            ))}
          </tbody>
        </table>

        <div className="px-6 py-4 text-xs text-gray-400">
          Showing {filteredClients.length} of {clients.length} clients
        </div>
      </div>

      {showModal && (
        <AddClientModal
          onClose={() => setShowModal(false)}
          onAdd={addClient}
        />
      )}
    </div>
  );
}

/* ===== COMPONENTS ===== */

function Stat({ title, value }) {
  return (
    <div className="bg-black/60 border border-white/10 rounded-2xl p-6">
      <p className="text-gray-400 text-sm">{title}</p>
      <h2 className="text-3xl font-bold text-[#39ff14]">{value}</h2>
    </div>
  );
}

function ClientRow({
  name,
  email,
  phone,
  membership,
  trainer,
  status,
  onDelete,
}) {
  const statusStyle = {
    Active: "bg-[#39ff14]/20 text-[#39ff14]",
    Expired: "bg-red-500/20 text-red-400",
    Paused: "bg-yellow-500/20 text-yellow-400",
  };

  return (
    <tr className="border-t border-white/10 hover:bg-white/5">
      <td className="px-6 py-4 flex gap-3 items-center">
        <img
          src={`https://i.pravatar.cc/40?u=${email}`}
          className="rounded-full"
        />
        <div>
          <p className="font-medium">{name}</p>
          <p className="text-xs text-gray-400">{email}</p>
        </div>
      </td>
      <td className="text-center">{email}</td>
      <td className="text-center">{phone}</td>
      <td className="text-center">
        <span className="bg-white/10 px-3 py-1 rounded-full text-xs">
          {membership}
        </span>
      </td>
      <td className="text-center">{trainer || "—"}</td>
      <td className="text-center">
        <span
          className={`px-3 py-1 rounded-full text-xs ${statusStyle[status]}`}
        >
          {status}
        </span>
      </td>
      <td className="px-6 text-right space-x-3">
        <button>👁</button>
        <button>✏️</button>
        <button onClick={onDelete}>🗑</button>
      </td>
    </tr>
  );
}

/* ===== ADD CLIENT MODAL ===== */

function AddClientModal({ onClose, onAdd }) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    membership: "Basic",
    trainer: "",
    status: "Active",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onAdd(form);
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
      <form
        onSubmit={handleSubmit}
        className="bg-black border border-white/10 rounded-xl p-6 w-full max-w-md"
      >
        <h2 className="text-xl font-bold mb-4">Add Client</h2>

        <input
          placeholder="Name"
          className="w-full mb-3 px-3 py-2 bg-black border border-white/10 rounded"
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <input
          placeholder="Email"
          className="w-full mb-3 px-3 py-2 bg-black border border-white/10 rounded"
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          required
        />
        <input
          placeholder="Phone"
          className="w-full mb-3 px-3 py-2 bg-black border border-white/10 rounded"
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          required
        />

        <select
          className="w-full mb-3 px-3 py-2 bg-black border border-white/10 rounded"
          onChange={(e) =>
            setForm({ ...form, membership: e.target.value })
          }
        >
          <option>Basic</option>
          <option>Pro</option>
          <option>Elite</option>
        </select>

        <input
          placeholder="Trainer (optional)"
          className="w-full mb-3 px-3 py-2 bg-black border border-white/10 rounded"
          onChange={(e) => setForm({ ...form, trainer: e.target.value })}
        />

        <select
          className="w-full mb-4 px-3 py-2 bg-black border border-white/10 rounded"
          onChange={(e) => setForm({ ...form, status: e.target.value })}
        >
          <option>Active</option>
          <option>Expired</option>
          <option>Paused</option>
        </select>

        <div className="flex justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="text-gray-400"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 rounded bg-[#39ff14] text-black font-semibold"
          >
            Add
          </button>
        </div>
      </form>
    </div>
  );
}
