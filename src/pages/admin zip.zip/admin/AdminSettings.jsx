import { useState } from "react";

export default function AdminSettings() {
  const [maintenance, setMaintenance] = useState(false);
  const [emailNotif, setEmailNotif] = useState(true);

  return (
    <div
      className="p-8 min-h-screen text-white max-w-5xl"
      style={{
        backgroundImage:
          "linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.85)), url('https://png.pngtree.com/thumb_back/fh260/background/20230721/pngtree-contemporary-3d-render-of-a-gym-with-modern-interior-design-image_3766556.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        backgroundAttachment: "fixed",
      }}
    >
      {/* HEADER */}
      <div className="mb-10">
        <h1 className="text-3xl font-bold">Admin Settings</h1>
        <p className="text-gray-400 mt-1">
          Manage system preferences and admin controls.
        </p>
      </div>

      {/* PROFILE */}
      <Section title="Admin Profile">
        <div className="flex items-center gap-6">
          <img
            src="https://i.pravatar.cc/80?img=68"
            alt="Admin"
            className="rounded-full"
          />
          <div>
            <p className="font-semibold text-lg">
              System Administrator
            </p>
            <p className="text-sm text-gray-400">
              admin@gympro.com
            </p>
          </div>
        </div>
      </Section>

      {/* SYSTEM SETTINGS */}
      <Section title="System Settings">
        <Toggle
          title="Maintenance Mode"
          desc="Temporarily disable user access"
          enabled={maintenance}
          setEnabled={setMaintenance}
        />
        <Toggle
          title="Email Notifications"
          desc="Receive system alerts and reports"
          enabled={emailNotif}
          setEnabled={setEmailNotif}
        />
      </Section>

      {/* SECURITY */}
      <Section title="Security">
        <div className="flex gap-4">
          <button className="border border-white/20 px-6 py-2 rounded-lg hover:bg-white/10">
            Change Password
          </button>
          <button className="bg-red-600 px-6 py-2 rounded-lg">
            Logout All Sessions
          </button>
        </div>
      </Section>

      {/* SAVE */}
      <div className="flex justify-end mt-10">
        <button className="bg-white text-black px-6 py-2 rounded-lg font-medium hover:bg-gray-200">
          Save Settings
        </button>
      </div>
    </div>
  );
}

/* COMPONENTS */

function Section({ title, children }) {
  return (
    <div className="mb-10">
      <h3 className="text-xl font-semibold mb-4">
        {title}
      </h3>
      <div className="bg-[#151515] border border-white/10 rounded-xl p-6 space-y-6">
        {children}
      </div>
    </div>
  );
}

function Toggle({ title, desc, enabled, setEnabled }) {
  return (
    <div className="flex justify-between items-center">
      <div>
        <p className="font-medium">{title}</p>
        <p className="text-sm text-gray-400">
          {desc}
        </p>
      </div>

      <button
        onClick={() => setEnabled(!enabled)}
        className={`w-12 h-6 rounded-full px-1 flex items-center transition ${
          enabled ? "bg-[#39ff14]" : "bg-white/20"
        }`}
      >
        <span
          className={`w-4 h-4 rounded-full transition ${
            enabled ? "bg-black ml-6" : "bg-white ml-0"
          }`}
        />
      </button>
    </div>
  );
}
